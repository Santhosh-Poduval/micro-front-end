import { Component } from '@angular/core';
import { Observable } from 'rxjs';

export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
  size: number;
  radius: number;
  energy: number;
  affinity: string;
  metalic: string;
  nonmetalic: string;
}

const ELEMENT_DATA: PeriodicElement[] = [


  

  { position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H', size: 21, radius: 12, energy: 10, affinity: 'afinity', metalic: 'metalic', nonmetalic: 'nonmetalic' },
  { position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H', size: 21, radius: 12, energy: 10, affinity: 'afinity', metalic: 'metalic', nonmetalic: 'nonmetalic' },
  { position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H', size: 21, radius: 12, energy: 10, affinity: 'afinity', metalic: 'metalic', nonmetalic: 'nonmetalic' }
  


];

@Component({
  selector: 'ngo-manage-categories',
  templateUrl: './manage-categories.component.html',
  styleUrls: ['./manage-categories.component.css']
})
export class ManageCategoriesComponent {

  isReadOnly = true;
  fullscreen$: Observable<boolean>;

  showFiller = false;
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol', 'size', 'radius', 'energy', 'affinity', 'metalic', 'nonmetalic'];
  dataSource = ELEMENT_DATA;

  public fullName: any;
  public str: any;
  notification = 2;
  showSpinner = false;

 
  
  pullDetails(row: any) {
   /** this.showSpinner = true;
    setTimeout(() => {
      this.showSpinner = false;
    }, 50000000000000000000000000000); **/
    this.fullName = row.name;
  }

  Edit(event : any){  
   this.isReadOnly  = this.isReadOnly == true ? false : true;   
  }


}
