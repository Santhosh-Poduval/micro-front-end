import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'ngo-general-categories',
  templateUrl: './general-categories.component.html',
  styleUrls: ['./general-categories.component.css']
})
export class GeneralCategoriesComponent implements OnInit {

  @Input("isReadOnly")  isReadOnly : boolean;
  Name: string = "Hello";
  Weight: string = "Hello";
  Symbol: string = "Hello";
  Size: string = "Hello";
  Radius: string = "Hello";
  Energy: string = "Hello";
 
  constructor() { 
 
    

  }

  ngOnInit() {
  }

}
