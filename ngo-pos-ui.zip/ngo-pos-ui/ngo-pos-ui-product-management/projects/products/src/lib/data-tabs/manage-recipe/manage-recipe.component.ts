import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngo-manage-recipe',
  templateUrl: './manage-recipe.component.html',
  styleUrls: ['./manage-recipe.component.css']
})
export class ManageRecipeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
