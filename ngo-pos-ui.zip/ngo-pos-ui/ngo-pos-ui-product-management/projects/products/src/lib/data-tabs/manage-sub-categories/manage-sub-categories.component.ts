import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngo-manage-sub-categories',
  templateUrl: './manage-sub-categories.component.html',
  styleUrls: ['./manage-sub-categories.component.css']
})
export class ManageSubCategoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
