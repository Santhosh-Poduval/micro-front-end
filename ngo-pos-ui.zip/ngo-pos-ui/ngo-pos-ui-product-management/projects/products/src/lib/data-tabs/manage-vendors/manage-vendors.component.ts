import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngo-manage-vendors',
  templateUrl: './manage-vendors.component.html',
  styleUrls: ['./manage-vendors.component.css']
})
export class ManageVendorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
