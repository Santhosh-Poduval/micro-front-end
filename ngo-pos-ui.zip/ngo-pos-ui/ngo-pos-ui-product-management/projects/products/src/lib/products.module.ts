import { NgModule,Injector } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { FormsModule } from '@angular/forms'

import { ProductsComponent } from './products.component';
import {ManageCategoriesComponent} from './data-tabs/manage-categories/manage-categories.component';
import {ManageProductComponent} from './data-tabs/manage-product/manage-product.component';
import {ManageRecipeComponent} from './data-tabs/manage-recipe/manage-recipe.component';
import {ManageSubCategoriesComponent} from './data-tabs/manage-sub-categories/manage-sub-categories.component';
import {ManageVendorsComponent} from './data-tabs/manage-vendors/manage-vendors.component';

import {GeneralCategoriesComponent } from './data-tabs/manage-categories/sections/general-categories/general-categories.component'

import { MaterialModule } from './material.module';


import { createCustomElement } from '@angular/elements';



@NgModule({
  declarations: [ProductsComponent,
  ManageCategoriesComponent,
  ManageProductComponent,
  ManageRecipeComponent,
  ManageSubCategoriesComponent,
  ManageVendorsComponent,
  GeneralCategoriesComponent],
  imports: [
    MaterialModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule
  ],
  exports: [ProductsComponent, ManageCategoriesComponent,
    ManageProductComponent,
    ManageRecipeComponent,
    ManageSubCategoriesComponent,
    ManageVendorsComponent,
    GeneralCategoriesComponent],
  entryComponents: [ProductsComponent]
})
export class ProductsModule { 

  constructor(private injector: Injector) {
    const demolibrary = createCustomElement(ProductsComponent, { injector });
    customElements.define('ngo-products', demolibrary);
}
ngDoBootstrap() {

}

}
