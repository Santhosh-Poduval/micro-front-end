/*
 * Public API Surface of products
 */

export * from './lib/products.service';
export * from './lib/products.component';
export * from './lib/products.module';
